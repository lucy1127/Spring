package com.example.Spring3_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring31Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring31Application.class, args);
	}

}
